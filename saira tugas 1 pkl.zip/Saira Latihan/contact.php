<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $subject = htmlspecialchars(trim($_POST['subject']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Validasi sederhana
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        echo "Semua field harus diisi.";
        exit;
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Email tidak valid.";
        exit;
    }

    // Pengaturan email tujuan (ganti dengan email kamu)
    $to = "your-email@example.com"; // Ganti dengan email admin yang ingin menerima pesan
    $email_subject = "Pesan baru dari: $name | $subject";
    $email_body = "Kamu menerima pesan dari: \n\n" .
                 "Nama: $name\n" .
                 "Email: $email\n" .
                 "Subjek: $subject\n\n" .
                 "Pesan:\n$message\n";
    
    // Header email
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    
    // Kirim email
    if (mail($to, $email_subject, $email_body, $headers)) {
        echo "Pesan berhasil dikirim.";
    } else {
        echo "Pesan gagal dikirim. Coba lagi.";
    }
}
?>
